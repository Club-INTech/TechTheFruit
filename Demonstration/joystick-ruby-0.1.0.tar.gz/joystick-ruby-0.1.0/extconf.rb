require 'mkmf'
create_makefile('joystick')
